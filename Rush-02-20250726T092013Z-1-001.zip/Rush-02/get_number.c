#include "read_file.c"
#include <stdio.h>
int main(int argc, char *argv)
{
    printf("%s", read_file("numbers.dict"));
}

/*
Con read_file("numbers.dic") obtenemos el string completo del diccionario,
el diccionario debe estar en la carpeta donde se compile el programa

La tarea para este archivo es separar los strings para hacerlos accesibles 
individualmente desde un array

La teoria es hacer un get_number(5) y obtener como respuesta five.

haz el diccionario accesible separando las palabras y numeros
string[0] = 0 
string[1] = zero

*/