#include <fcntl.h>   // Para open()
#include <stdlib.h>  // Para malloc() y free()
#include <unistd.h>  // Para read() y close()

// Tamaño del buffer que usaremos para leer el archivo en partes

// Función para leer un archivo completo y devolver su contenido como una cadena
char *read_file(const char *filename)
{
    #define BUFFER_SIZE 1024
    int     fd;                     // File descriptor
    char    buffer[BUFFER_SIZE];    // Buffer temporal para leer datos
    char    *result = NULL;         // Apuntador al contenido final
    char    *temp;                  // Variable temporal para realocar memoria
    ssize_t bytes_read;             // Cuántos bytes se leyeron | definidos en unistd
    size_t  total_size = 0;         // Tamaño total leído hasta ahora | representan numero de bytes leidos

    // 1. Abrimos el archivo en modo lectura
    fd = open(filename, O_RDONLY);
    if (fd < 0)
        return (NULL);  // Si no se puede abrir, retornamos NULL

    // 2. Leemos el archivo en partes (se guarda en buffer y buffersize son losbytes que lee cada llamada
    while ((bytes_read = read(fd, buffer, BUFFER_SIZE)) > 0)
    {
        // 3. Reservamos espacio nuevo para guardar lo leído hasta ahora + nuevo contenido
        temp = malloc(total_size + bytes_read + 1);  // +1 para el '\0'
        if (!temp) //Si temp es null return null
            return (NULL);  // Si malloc falla, retornamos NULL
        size_t  i;

        i = 0;
        // 4. Copiamos el contenido anterior (si existe) al nuevo espacio
        while (i < total_size)
        {
            temp[i] = result[i];
            ++i;
        }

        // 5. Copiamos lo nuevo que acabamos de leer
        i = 0;
        while (i < bytes_read)
        {
            temp[total_size + i] = buffer[i];
            i++;
        }


        total_size += bytes_read;          // Actualizamos el tamaño total
        temp[total_size] = '\0';           // Recuerda se lee por bloques, una vez leido el primero se guardan los datos al principio de un string, a la siguiente vuelta se suma los proximos datos leidos a ese string

        free(result);                      // Liberamos la memoria anterior
        result = temp;                     // Ahora result apunta al contenido actualizado
        /*free(temp); Seguir las instrucciones del proyecto desalojando la memoria genera un bug*/
    }
    //Cerrar el archivo
    close(fd);
    return result;  // Retornamos el contenido del archivo
}


/*
#include <stdio.h>
int main(int argc, char *argv)
{
    printf("%s", read_file("numbers.dict"));
}
*/
