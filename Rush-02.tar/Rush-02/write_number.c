/*
FUNCION PRINCIPAL, DESDE AQUI SE ANALIZA TODO EL NUMERO ENTERO.
SE LLAMA A GETNUMBER LAS VECES NECESARIAS PARA ESCRIBIR TODO EL NUMERO

COMPORTAMIENTO:


Funcion_aproximada(no funciona pero es la idea) {

char *string;

while(number >= 10) {
    digit = nb % 10 + '0';
    nb /= 10;

    string += get_number(digit) //Aqui llamas a getnumber que convierte un numero a texto
}
return string;
}

*/