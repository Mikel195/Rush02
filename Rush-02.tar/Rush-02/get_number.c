#include "read_file.c"
#include <stdio.h>
int main(int argc, char *argv[])
{
    printf("%s", read_file("numbers.dict"));
}

/*
OBJETIVO: SEPARAR EL STRING QUE DEVUELVE read_file("numbers.dict")
Almacenar en un array a el mumero, seguido de sus letras de tal manera que haciendo array[x + 1] devuelva el numero en letras

El comportamiento de get_number debe ser: recibir como parametro un numero entero y devolverlo en texto


    CODIGO SIN CORREGIR(SI FUNCIONA SE PUEDE USAR DE MOMENTO) SEPARADOR DE STRINGS

    char *my_strtok(char *str, const char *delim) {
    static char *static_str = NULL; // Cadena para continuar entre llamadas
    int i = 0, j = 0;

    if (str != NULL) {
        static_str = str;
    }
    if (static_str == NULL) {
        return NULL;
    }

    while (static_str[i] != '\0') {
        for (j = 0; delim[j] != '\0'; j++) {
            if (static_str[i] == delim[j]) {
                i++;
                break;
            }
        }
        if (delim[j] == '\0') break;
    }

    if (static_str[i] == '\0') {
        static_str = NULL;
        return NULL;
    }

    char *start = &static_str[i];

    while (static_str[i] != '\0') {
        for (j = 0; delim[j] != '\0'; j++) {
            if (static_str[i] == delim[j]) {
                static_str[i] = '\0';
                static_str = &static_str[i + 1];
                return start;
            }
        }
        i++;
    }

    static_str = NULL;
    return start;
}

*/

